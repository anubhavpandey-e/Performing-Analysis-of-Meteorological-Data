# Internship_at_suvenconsultants
Goal Behind it
One type of data that's easier to find on the net is Weather data. Many sites provide historical data on many meteorological parameters such as pressure, temperature, humidity, wind_speed, visibility, etc.

My goal in this Internship (of data analysis) is to transform the raw data into information and then convert it into knowledge.
I am very excited to share with you my internship's first project.

Conclusion:

According to Jan-Dec graph visulization, april to august month's temprature change is very less. Its almost same for all year.But there is no change in humidity for last 10 year[2006–2016] for a perticular month.Again september to march, there is very huge change in temperature but humidity is remain unchanged.
